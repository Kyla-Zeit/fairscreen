export default {
  trailingComma: "all",
};
